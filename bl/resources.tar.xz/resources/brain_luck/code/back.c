char getc() {
    int c;
    __asm__getc(c);
    return c;
}
int main() {
    int x = 0;
    int c = 0;

    while (c = getc()) {
        __reg_xd = 'a';
        if (c == 'A') break;
        x = x + c;
    }
    __asm__mov(x, __reg_xd);
    return x;
}
